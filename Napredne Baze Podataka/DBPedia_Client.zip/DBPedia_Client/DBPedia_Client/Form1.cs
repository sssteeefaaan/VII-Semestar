﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using VDS.RDF;
using VDS.RDF.Parsing;
using VDS.RDF.Query;

namespace DBPedia_Client
{
    public partial class Form1 : Form
    {
        private SparqlRemoteEndpoint dbpedia_sparql_endpoint;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //IGraph g = new Graph();
            //UriLoader.Load(g, new Uri("http://spatial.ucd.ie/osn/skos/osm_semantic_network_mappings.rdf"));
            //foreach(INode node in g.Nodes)
            //{
            //    INode inode = node;
            //}

            dbpedia_sparql_endpoint = new SparqlRemoteEndpoint(new Uri("http://dbpedia.org/sparql"), "http://dbpedia.org");

            dbpedia_sparql_endpoint.Timeout = 120000;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string sparql = "SELECT ?film WHERE { ?film <http://purl.org/dc/terms/subject> <http://dbpedia.org/resource/Category:Japanese_films>.} limit 500";

            SparqlQueryParser parser = new SparqlQueryParser();

            SparqlQuery sparqlQuery = parser.ParseFromString(sparql);

            SparqlResultSet movies = dbpedia_sparql_endpoint.QueryWithResultSet(sparql);

            Graph g = (Graph)dbpedia_sparql_endpoint.QueryWithResultGraph(sparql);

            foreach(SparqlResult movie in movies)
            {
                UriNode node = (UriNode)movie.Value(movie.Variables.First());
                MessageBox.Show(node.Uri.ToString());
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            SparqlParameterizedString sparql = new SparqlParameterizedString();

            sparql.Namespaces.AddNamespace("rdfs", new Uri("http://www.w3.org/2000/01/rdf-schema#"));
            sparql.Namespaces.AddNamespace("dbp-ont", new Uri("http://dbpedia.org/ontology/"));

            sparql.CommandText = "select ?label ?address" +
                                "where" +
                                "{" +
                                    "?rest a dbp-ont:Restaurant;" +
                                    "rdfs:label ?label;" +
                                    "dbp-ont:address ?address." +
                                    "FILTER(lang(?label)=\"en\")." +
                                    "FILTER(regex(?address, \"Manhattan*?\"))" +
                                "}";

            SparqlQueryParser parser = new SparqlQueryParser();
            SparqlQuery sparqlQuery = parser.ParseFromString(sparql);


            SparqlResultSet restaurants = dbpedia_sparql_endpoint.QueryWithResultSet(sparqlQuery.ToString());

            foreach(SparqlResult restaurant in restaurants)
            {
                LiteralNode restaurantName = (LiteralNode) restaurant.Value(restaurant.Variables.First());

                MessageBox.Show(restaurantName.Value);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            SparqlParameterizedString sparql = new SparqlParameterizedString();

            sparql.Namespaces.AddNamespace("dbpprop", new Uri("http://dbpedia.org/property/"));
            sparql.Namespaces.AddNamespace("rdfs", new Uri("http://www.w3.org/2000/01/rdf-schema#"));
            sparql.Namespaces.AddNamespace("dbpedia-owl", new Uri("http://dbpedia.org/ontology/"));
            sparql.Namespaces.AddNamespace("rdf", new Uri("http://www.w3.org/1999/02/22-rdf-syntax-ns#"));
            
            sparql.CommandText = "select distinct ?city ?pop " +
                                 "where " +
                                 "{ " +
                                    "?city rdf:type dbpedia-owl:Settlement; " +
                                    "rdfs:label ?label; " +
                                    "dbpedia-owl:country ?country; " +
                                    "dbpedia-owl:populationTotal ?pop. "+
                                    "FILTER(regex(?country, \"United_States*?\")) " +
                                 "} LIMIT 1000";

            SparqlQueryParser parser = new SparqlQueryParser();
            SparqlQuery sparqlQuery = parser.ParseFromString(sparql);

            
            SparqlResultSet settlements = dbpedia_sparql_endpoint.QueryWithResultSet(sparqlQuery.ToString());

            foreach (SparqlResult settlement in settlements)
            {
                UriNode settlementNode = (UriNode)settlement.Value(settlement.Variables.First());
                LiteralNode settlementPopulationNode = (LiteralNode)settlement.Value(settlement.Variables.ElementAt(1));

                MessageBox.Show(settlementNode.Uri.ToString());
            }

        }

        private void button4_Click(object sender, EventArgs e)
        {
            SparqlParameterizedString sparql = new SparqlParameterizedString();

            sparql.Namespaces.AddNamespace("owl", new Uri("http://www.w3.org/2002/07/owl#"));
            sparql.Namespaces.AddNamespace("xsd", new Uri("http://www.w3.org/2001/XMLSchema#"));
            sparql.Namespaces.AddNamespace("rdfs", new Uri("http://www.w3.org/2000/01/rdf-schema#"));
            sparql.Namespaces.AddNamespace("rdf", new Uri("http://www.w3.org/1999/02/22-rdf-syntax-ns#"));
            sparql.Namespaces.AddNamespace("foaf", new Uri("http://xmlns.com/foaf/0.1/"));
            sparql.Namespaces.AddNamespace("dc", new Uri("http://purl.org/dc/elements/1.1/"));
            //sparql.Namespaces.AddNamespace("dbo", new Uri("http://dbpedia.org/resource/"));
            sparql.Namespaces.AddNamespace("dbpedia2", new Uri("http://dbpedia.org/property/"));
            sparql.Namespaces.AddNamespace("dbpedia", new Uri("http://dbpedia.org/"));
            sparql.Namespaces.AddNamespace("skos", new Uri("http://www.w3.org/2004/02/skos/core#"));
            sparql.Namespaces.AddNamespace("dbo", new Uri("http://dbpedia.org/ontology/"));

            sparql.CommandText = "SELECT ?name ?birth ?death ?person" + 
                                 "where" +
                                 "{" +
                                    "?person dbpedia2:birthPlace <http://dbpedia.org/resource/Berlin> ." +
                                    "?person dbo:birthDate ?birth ." +
                                    "?person foaf:name ?name ." +
                                    "?person dbo:deathDate ?death ." +
                                    "FILTER(?birth < xsd:dateTime(\"1900-01-01\"))." +
                                 "}";


            SparqlQueryParser parser = new SparqlQueryParser();
            SparqlQuery sparqlQuery = parser.ParseFromString(sparql);


            SparqlResultSet persons = dbpedia_sparql_endpoint.QueryWithResultSet(sparqlQuery.ToString());

            foreach (SparqlResult person in persons)
            {
                LiteralNode personNode = (LiteralNode)person.Value(person.Variables.First());

                MessageBox.Show(personNode.Value);
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            SparqlParameterizedString sparql = new SparqlParameterizedString();

            sparql.Namespaces.AddNamespace("rdfs", new Uri("http://www.w3.org/2000/01/rdf-schema#"));

            sparql.CommandText = "SELECT *" +
                                 "WHERE" +
                                 "{" +
                                 "?cls rdfs:subClassOf <http://dbpedia.org/class/yago/Church103028079> ." +
                                 "?inst a ?cls" +
                                 "}";

            SparqlQueryParser parser = new SparqlQueryParser();
            SparqlQuery sparqlQuery = parser.ParseFromString(sparql);


            SparqlResultSet churches = dbpedia_sparql_endpoint.QueryWithResultSet(sparqlQuery.ToString());

            foreach (SparqlResult church in churches)
            {
                UriNode churchNode = (UriNode)church.Value(church.Variables.First());

                MessageBox.Show(churchNode.Uri.ToString());
            }
        }


    }
}
