
public class sym {

	public final static int EOF = 0;
	public final static int PROGRAM = 1;
	public final static int VAR = 2;
	public final static int INTEGER = 3;
	public final static int CHAR = 4;
	public final static int BEGIN = 5;
	public final static int END = 6;
	public final static int READ = 7;
	public final static int WRITE = 8;
	public final static int IF = 9;
	public final static int THEN = 10;
	public final static int ELSE = 11;
	public final static int ID = 12;
	public final static int CONST = 13;
	public final static int PLUS = 14;
	public final static int MUL = 15;
	public final static int LEFTPAR = 16;
	public final static int RIGHTPAR = 17;
	public final static int ASSIGN = 18;
	public final static int SEMICOLON = 19;
	public final static int COMMA = 20;
	public final static int DOT = 21;
	public final static int COLON = 22;

}
