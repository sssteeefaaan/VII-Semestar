package jflex.core.unicode;

public interface ILexScan {

  UnicodeProperties getUnicodeProperties();
}
