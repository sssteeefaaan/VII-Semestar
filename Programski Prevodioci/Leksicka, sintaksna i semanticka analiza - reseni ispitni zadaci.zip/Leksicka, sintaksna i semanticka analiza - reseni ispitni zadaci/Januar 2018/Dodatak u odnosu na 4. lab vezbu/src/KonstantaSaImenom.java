import SymbolTable.*; 

public class KonstantaSaImenom {
	public String ime;
	public Constant konstanta;
	
	public KonstantaSaImenom (String ime, Constant konstanta) {
		this.ime = ime;
		this.konstanta = konstanta;
	}

}
