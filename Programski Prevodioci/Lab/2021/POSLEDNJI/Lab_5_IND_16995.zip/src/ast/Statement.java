package ast;





public abstract class Statement extends ASTNode{

}
