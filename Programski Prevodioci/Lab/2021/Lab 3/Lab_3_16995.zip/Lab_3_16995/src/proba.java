public class proba {
    public static void main(String[] args)
    {
        System.out.println("Vrednost");
        System.out.println(Boolean.parseBoolean("false"));
    }
}
